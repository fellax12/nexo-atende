# Nexo Atende 0.1.3 — reconstrução a partir do APK 0.1.2

Este projeto foi reconstruído usando como referência o APK 0.1.2 fornecido e preserva `assets/index.html` da versão original.

## Foco da 0.1.3
- `NotificationListenerService` explícito e rebind ao reconectar.
- Filtro exclusivo para `com.whatsapp.w4b`.
- Captura de título/texto da notificação.
- Filtro de grupo, lista de contatos de teste e contatos pausados.
- Busca de ação com `RemoteInput` e envio pela ação de resposta da notificação.
- Sinais de diagnóstico persistidos (`lastSignal`) e logs locais.
- Ponte JavaScript compatível com a interface 0.1.2.

## Compilar
Abra a pasta no Android Studio (JDK 17) e faça Sync/Build APK. O ambiente desta conversa não contém Android SDK/aapt2/apksigner, portanto o pacote entregue aqui é o projeto-fonte reconstruído, não um APK assinado.

## Teste crítico
1. Instale o APK gerado.
2. Abra Conexão e autorize acesso às notificações.
3. Mantenha apenas um contato de teste autorizado.
4. Ative o piloto.
5. Com o WhatsApp Business fora do primeiro plano, envie `oi` de outro número.
6. Confira Conversas e o diagnóstico.

A integração por notificação depende do formato que o WhatsApp Business e o Android/MIUI expõem no aparelho. O envio via `PendingIntent` aceito pelo Android não garante entrega pela Meta/WhatsApp.
