package br.com.nexo.atende;

import org.json.*;
import java.util.*;

public class BotEngine {
    public static class Reply { public String text,kind,rule; public boolean pause; Reply(String t,String k,String r,boolean p){text=t;kind=k;rule=r;pause=p;} }
    public static Reply respond(JSONObject c,String raw){
        String n=AppStore.norm(raw); if(n.isEmpty()) return null;
        if(n.matches(".*\\b(parar|pare|atendente|humano|falar com atendente|falar com uma pessoa)\\b.*") || n.equals("4")) return new Reply("Certo. Vou pausar as respostas automáticas para você continuar com a equipe.","human","Atendimento humano",true);
        if(n.equals("oi")||n.equals("ola")||n.equals("menu")||n.equals("bom dia")||n.equals("boa tarde")||n.equals("boa noite")) return new Reply(fill(c,c.optString("greeting"))+"\n\n1. Produtos e serviços\n2. Horários\n3. Endereço\n4. Falar com a equipe","reply","Menu inicial",false);
        if(n.equals("1")) return new Reply(nonempty(c.optString("catalog"),"O catálogo ainda não foi cadastrado."),"reply","Menu · catálogo",false);
        if(n.equals("2")) return new Reply(nonempty(c.optString("hours"),"O horário ainda não foi cadastrado."),"reply","Menu · horário",false);
        if(n.equals("3")) return new Reply(nonempty(c.optString("address"),"O endereço ou região ainda não foi cadastrado."),"reply","Menu · endereço",false);
        JSONArray rules=c.optJSONArray("rules"); if(rules!=null) for(int i=0;i<rules.length();i++){JSONObject r=rules.optJSONObject(i); if(r==null||!r.optBoolean("enabled",true))continue; String kws=r.optString("keywords",""); for(String k:kws.split("[,\\n]")){String q=AppStore.norm(k);if(!q.isEmpty()&&n.contains(q)) return new Reply(fill(c,r.optString("response")),"reply",r.optString("name","Regra"),false);}}
        return new Reply(fill(c,c.optString("fallback","Não encontrei uma resposta cadastrada para essa pergunta.")),"fallback","Fallback",false);
    }
    private static String nonempty(String s,String f){return s==null||s.trim().isEmpty()?f:s;}
    public static String fill(JSONObject c,String s){ if(s==null)return ""; return s.replace("{empresa}",c.optString("company")).replace("{nome}",c.optString("company")).replace("{assistente}",c.optString("assistant")).replace("{horario}",c.optString("hours")).replace("{endereco}",c.optString("address")).replace("{catalogo}",c.optString("catalog")); }
}
