package br.com.nexo.atende;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.text.Normalizer;
import java.util.*;

public class AppStore {
    private final SharedPreferences p;
    public AppStore(Context c){ p=c.getSharedPreferences("nexo",Context.MODE_PRIVATE); }
    public synchronized JSONObject config(){
        try {
            JSONObject d=defaultConfig(), saved=new JSONObject(p.getString("config", "{}"));
            Iterator<String> keys=saved.keys(); while(keys.hasNext()){String k=keys.next();d.put(k,saved.get(k));}
            return d;
        } catch(Exception e){ return defaultConfig(); }
    }
    public synchronized void saveConfig(JSONObject o){ p.edit().putString("config",o.toString()).apply(); }
    public boolean accepted(){ return p.getBoolean("accepted",false); }
    public void accepted(boolean v){ p.edit().putBoolean("accepted",v).apply(); }
    public boolean enabled(){ return p.getBoolean("enabled",false); }
    public void enabled(boolean v){ p.edit().putBoolean("enabled",v).apply(); }
    public synchronized JSONArray logs(){ try{return new JSONArray(p.getString("logs","[]"));}catch(Exception e){return new JSONArray();} }
    public synchronized void clearLogs(){ p.edit().putString("logs","[]").apply(); }
    public synchronized void log(String contact,String input,String output,String kind,String detail){
        JSONArray a=logs(); JSONObject x=new JSONObject();
        try{ String id=UUID.randomUUID().toString(); String state=("reply".equals(kind)||"fallback".equals(kind)||"away".equals(kind))?"requested":kind; x.put("id",id);x.put("key",id);x.put("time",System.currentTimeMillis());x.put("contact",contact);x.put("input",input);x.put("output",output);x.put("reply",output);x.put("kind",kind);x.put("state",state);x.put("detail",detail);x.put("reason",detail);x.put("paused",isPaused(contact)); a.put(x); while(a.length()>200){ JSONArray n=new JSONArray();for(int i=1;i<a.length();i++)n.put(a.get(i));a=n;} p.edit().putString("logs",a.toString()).apply(); }catch(Exception ignored){}
    }
    public boolean isPaused(String contact){ return p.getBoolean("pause_"+norm(contact),false); }
    public void pause(String contact,boolean v){ p.edit().putBoolean("pause_"+norm(contact),v).apply(); }
    public long lastReplyAt(String contact){ return p.getLong("reply_"+norm(contact),0); }
    public void markReply(String contact){ p.edit().putLong("reply_"+norm(contact),System.currentTimeMillis()).apply(); }
    public long lastAwayAt(String contact){ return p.getLong("away_"+norm(contact),0); }
    public void markAway(String contact){ p.edit().putLong("away_"+norm(contact),System.currentTimeMillis()).apply(); }
    public String lastSignal(){return p.getString("lastSignal","");}
    public void signal(String s){p.edit().putString("lastSignal",s).putLong("lastSignalAt",System.currentTimeMillis()).apply();}
    public long lastSignalAt(){return p.getLong("lastSignalAt",0);}
    public static String norm(String s){ if(s==null)return ""; return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).trim(); }
    public static JSONObject defaultConfig(){
        try{return new JSONObject("{\"schema\":1,\"company\":\"\",\"assistant\":\"Assistente\",\"segment\":\"Serviços\",\"address\":\"\",\"catalog\":\"\",\"hours\":\"\",\"greeting\":\"Olá! Sou o assistente automático da {empresa}. Como posso ajudar?\",\"fallback\":\"Não encontrei uma resposta cadastrada para essa pergunta. Digite 4 para falar com a equipe.\",\"away\":\"No momento estamos fora do horário de atendimento.\",\"handoff\":\"Certo. Vou pausar as respostas automáticas para você continuar com a equipe.\",\"schedule\":false,\"days\":[2,3,4,5,6],\"start\":540,\"end\":1080,\"rules\":[],\"allowlistEnabled\":true,\"allowlist\":\"\",\"replyDelay\":2000,\"theme\":\"midnight\",\"appearance\":\"system\",\"colorCompatibility\":false}");}catch(Exception e){return new JSONObject();}
    }
}
