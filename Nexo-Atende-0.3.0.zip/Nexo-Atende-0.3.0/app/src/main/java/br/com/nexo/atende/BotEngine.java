package br.com.nexo.atende;

import org.json.*;
import java.util.*;

public class BotEngine {
    public static class Reply { public String text,kind,rule; public boolean pause; Reply(String t,String k,String r,boolean p){text=t;kind=k;rule=r;pause=p;} }
    public static Reply respond(JSONObject c,String raw){
        String n=AppStore.norm(raw); if(n.isEmpty()) return null;
        if(n.matches(".*\\b(parar|pare|atendente|humano|falar com atendente|falar com uma pessoa)\\b.*") || n.equals("4"))
            return new Reply(nonempty(fill(c,c.optString("handoff")),"Certo. Vou pausar as respostas automáticas para você continuar com a equipe."),"human","Atendimento humano",true);
        if(c.optBoolean("schedule",false) && !insideSchedule(c))
            return new Reply(nonempty(fill(c,c.optString("away")),"No momento estamos fora do horário de atendimento."),"away","Fora do horário",false);
        if(n.equals("1")) return new Reply(nonempty(fill(c,c.optString("catalog")),"O catálogo ainda não foi cadastrado."),"reply","Menu · catálogo",false);
        if(n.equals("2")) return new Reply(nonempty(fill(c,c.optString("hours")),"O horário ainda não foi cadastrado."),"reply","Menu · horário",false);
        if(n.equals("3")) return new Reply(nonempty(fill(c,c.optString("address")),"O endereço ou região ainda não foi cadastrado."),"reply","Menu · endereço",false);
        // User-created rules take priority over the generic greeting.
        JSONArray rules=c.optJSONArray("rules");
        if(rules!=null) for(int i=0;i<rules.length();i++){
            JSONObject r=rules.optJSONObject(i); if(r==null||!r.optBoolean("enabled",true))continue;
            String mode=r.optString("mode","contains");
            String kws=r.optString("keywords","");
            for(String k:kws.split("[,;\\n]")){
                String q=AppStore.norm(k); if(q.isEmpty())continue;
                boolean match="exact".equals(mode)?n.equals(q):n.contains(q);
                if(match) return new Reply(fill(c,r.optString("reply",r.optString("response"))),"reply",r.optString("name","Regra"),false);
            }
        }
        if(n.equals("oi")||n.equals("ola")||n.equals("menu")||n.equals("bom dia")||n.equals("boa tarde")||n.equals("boa noite"))
            return new Reply(fill(c,c.optString("greeting"))+"\n\n1. Produtos e serviços\n2. Horários\n3. Endereço\n4. Falar com a equipe","reply","Menu inicial",false);
        return new Reply(fill(c,c.optString("fallback","Não encontrei uma resposta cadastrada para essa pergunta.")),"fallback","Fallback",false);
    }
    private static boolean insideSchedule(JSONObject c){
        JSONArray days=c.optJSONArray("days"); if(days==null||days.length()==0)return false;
        Calendar now=Calendar.getInstance(); int day=now.get(Calendar.DAY_OF_WEEK); // 1=domingo
        int mins=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        int start=c.optInt("start",540), end=c.optInt("end",1080);
        if(start==end) return selected(days,day);
        if(end>start) return selected(days,day)&&mins>=start&&mins<end;
        if(mins>=start) return selected(days,day);
        int prev=day==Calendar.SUNDAY?Calendar.SATURDAY:day-1;
        return mins<end&&selected(days,prev);
    }
    private static boolean selected(JSONArray a,int d){for(int i=0;i<a.length();i++)if(a.optInt(i)==d)return true;return false;}
    private static String nonempty(String s,String f){return s==null||s.trim().isEmpty()?f:s;}
    public static String fill(JSONObject c,String s){ if(s==null)return ""; return s.replace("{empresa}",c.optString("company")).replace("{nome}",c.optString("company")).replace("{assistente}",c.optString("assistant")).replace("{horario}",c.optString("hours")).replace("{endereco}",c.optString("address")).replace("{catalogo}",c.optString("catalog")); }
}
