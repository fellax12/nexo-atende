package br.com.nexo.atende;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import android.view.*;
import android.graphics.Insets;
import org.json.*;
import java.io.*;

public class MainActivity extends Activity {
    private WebView web; private AppStore store; private static final int CREATE=41,OPEN=42;
    @Override public void onCreate(Bundle b){super.onCreate(b);store=new AppStore(this);web=new WebView(this);setContentView(web); applySystemInsets(); WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setBlockNetworkLoads(true);web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(),"NexoNative");web.loadUrl("file:///android_asset/index.html");}
    @Override protected void onResume(){super.onResume(); if(web!=null)web.evaluateJavascript("window.reloadState&&window.reloadState(true)",null);}

    private void applySystemInsets(){
        // Keep the app inside the real usable screen area on modern Android.
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().setNavigationBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().setDecorFitsSystemWindows(true);
        }
        web.setPadding(0,0,0,0);
    }
    private boolean notificationAllowed(){String flat=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");return flat!=null&&flat.contains(getPackageName());}
    private boolean whatsappInstalled(){try{getPackageManager().getPackageInfo("com.whatsapp.w4b",0);return true;}catch(Exception e){return false;}}
    public class Bridge {
        @JavascriptInterface public String snapshot(){JSONObject x=new JSONObject();try{x.put("config",store.config());x.put("enabled",store.enabled());x.put("accepted",store.accepted());x.put("notificationAllowed",notificationAllowed());x.put("listenerConnected",ReplyService.connected);x.put("whatsappInstalled",whatsappInstalled());x.put("logs",store.logs());int rep=0,err=0;JSONArray a=store.logs();for(int i=0;i<a.length();i++){String k=a.optJSONObject(i).optString("kind");if("error".equals(k))err++;else if("reply".equals(k)||"fallback".equals(k))rep++;}x.put("totalReplies",rep);x.put("totalErrors",err);x.put("version","0.3.0 · candidato de apresentação");x.put("lastSignal",store.lastSignal());x.put("lastSignalAt",store.lastSignalAt());}catch(Exception ignored){}return x.toString();}
        @JavascriptInterface public String saveConfig(String json){try{store.saveConfig(new JSONObject(json));return ok("Alterações salvas neste aparelho.");}catch(Exception e){return fail("Configuração inválida.");}}
        @JavascriptInterface public String simulate(String text,String contact){BotEngine.Reply r=BotEngine.respond(store.config(),text);JSONObject x=new JSONObject();try{if(r==null)return "{}";x.put("text",r.text);x.put("kind",r.kind);x.put("rule",r.rule);x.put("pause",r.pause);}catch(Exception ignored){}return x.toString();}
        @JavascriptInterface public void acceptPilot(){store.accepted(true);reload();}
        @JavascriptInterface public String setEnabled(boolean v){if(v&&!notificationAllowed())return fail("Autorize o acesso às notificações primeiro.");store.enabled(v); if(v){try{android.service.notification.NotificationListenerService.requestRebind(new ComponentName(MainActivity.this,ReplyService.class));}catch(Exception ignored){}}reload();return ok(v?"Piloto ativado.":"Assistente pausado.");}
        @JavascriptInterface public void pauseContact(String id,boolean paused){JSONArray a=store.logs();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&id.equals(o.optString("id"))){store.pause(o.optString("contact"),!paused);break;}}reload();}
        @JavascriptInterface public void clearHistory(){store.clearLogs();reload();}
        @JavascriptInterface public void notificationSettings(){launch(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}
        @JavascriptInterface public void appSettings(){launch(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
        @JavascriptInterface public void batterySettings(){launch(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}
        @JavascriptInterface public void openWhatsapp(){try{Intent i=getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");if(i!=null)launch(i);}catch(Exception ignored){}}
        @JavascriptInterface public void exportConfig(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"nexo-atende-config.json");startActivityForResult(i,CREATE);}
        @JavascriptInterface public void importConfig(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,OPEN);}
        private String ok(String m){return "{\"ok\":true,\"message\":"+JSONObject.quote(m)+"}";} private String fail(String m){return "{\"ok\":false,\"message\":"+JSONObject.quote(m)+"}";}
    }
    private void launch(Intent i){try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir esta configuração.",Toast.LENGTH_LONG).show();}}
    private void reload(){runOnUiThread(()->web.evaluateJavascript("window.reloadState&&window.reloadState(true)",null));}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;Uri u=data.getData();try{if(req==CREATE){try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(store.config().toString(2).getBytes("UTF-8"));}}else if(req==OPEN){StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(u)))){String l;while((l=r.readLine())!=null)b.append(l);}JSONObject o=new JSONObject(b.toString());if(o.optInt("schema",0)!=1)throw new Exception("schema");store.saveConfig(o);store.enabled(false);reload();}}catch(Exception e){Toast.makeText(this,"Não foi possível processar o arquivo.",Toast.LENGTH_LONG).show();}}
}
