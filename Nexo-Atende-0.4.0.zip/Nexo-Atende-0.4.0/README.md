# Nexo Atende 0.4.0 — Automação

## Destaques
- Deduplicação persistente + trava em memória para reduzir respostas duplas.
- Fluxos e submenus por estado de conversa.
- Regras: contém, mensagem exata e começa com.
- Estado de entrada, próximo estado e encerramento de fluxo configuráveis na interface.
- Menu inicial continua funcionando sem configuração adicional.
- Horários, handoff humano, allowlist, simulador e histórico preservados.
- Janela anti-duplicação configurável (45 s recomendados).

## Limite técnico do modo local
A resposta automática usa NotificationListenerService + RemoteInput do Android. Botões nativos do WhatsApp e envio confiável de mídia não fazem parte deste motor local; uma futura integração oficial pode adicioná-los.
