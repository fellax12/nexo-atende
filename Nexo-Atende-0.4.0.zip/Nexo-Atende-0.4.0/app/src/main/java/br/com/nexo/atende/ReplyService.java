package br.com.nexo.atende;

import android.app.*;
import android.content.*;
import android.os.*;
import android.service.notification.*;
import org.json.JSONObject;
import java.util.*;

public class ReplyService extends NotificationListenerService {
    public static volatile boolean connected=false;
    private final Map<String,Long> inFlight=new HashMap<>();
    private AppStore store;
    @Override public void onCreate(){super.onCreate();store=new AppStore(this);}
    @Override public void onListenerConnected(){connected=true;store.signal("Listener conectado");super.onListenerConnected();}
    @Override public void onListenerDisconnected(){connected=false;store.signal("Listener desconectado");super.onListenerDisconnected();try{requestRebind(new ComponentName(this,ReplyService.class));}catch(Exception ignored){}}
    @Override public synchronized void onNotificationPosted(StatusBarNotification sbn){
        if(store==null)store=new AppStore(this); if(sbn==null||!"com.whatsapp.w4b".equals(sbn.getPackageName()))return;
        Notification n=sbn.getNotification(); if(n==null)return; Bundle e=n.extras;
        String contact=cs(e.getCharSequence(Notification.EXTRA_TITLE)); String body=cs(e.getCharSequence(Notification.EXTRA_TEXT));
        if(!store.enabled()||contact.isEmpty()||body.isEmpty())return;
        if(e.getBoolean("android.isGroupConversation",false)){store.log(contact,body,"","ignored","Grupo ignorado");return;}
        if(store.isPaused(contact)){store.log(contact,body,"","paused","Contato pausado");return;}
        JSONObject cfg=store.config(); JSONObjectSafe safe=new JSONObjectSafe(cfg);
        if(safe.bool("allowlistEnabled",true)&&!allowed(contact,safe.str("allowlist"))){store.log(contact,body,"","ignored","Nome fora da lista de teste");return;}

        long now=System.currentTimeMillis();
        String fingerprint=AppStore.norm(contact)+"|"+AppStore.norm(body);
        long window=Math.max(8000,Math.min(120000,safe.integer("dedupeWindow",45000)));
        Long active=inFlight.get(fingerprint);
        if((active!=null&&now-active<window)||(now-store.fingerprintAt(fingerprint)<window))return;
        inFlight.put(fingerprint,now); store.markFingerprint(fingerprint);
        inFlight.entrySet().removeIf(x->now-x.getValue()>120000);

        String flow=store.conversationState(contact);
        BotEngine.Reply r=BotEngine.respond(cfg,body,flow); if(r==null){inFlight.remove(fingerprint);return;}
        if("away".equals(r.kind)&&now-store.lastAwayAt(contact)<30*60*1000L){store.log(contact,body,"","ignored","Aviso de ausência já enviado recentemente");return;}
        if(r.pause)store.pause(contact,true);
        Notification.Action action=findReply(n.actions); if(action==null){store.log(contact,body,r.text,"error","Sem ação Responder utilizável");store.signal("Sem ação Responder utilizável");return;}
        long delay=Math.max(0,Math.min(15000,safe.integer("replyDelay",2000)));
        new Handler(Looper.getMainLooper()).postDelayed(()->send(action,contact,body,r,fingerprint),delay);
    }
    private void send(Notification.Action action,String contact,String body,BotEngine.Reply r,String fingerprint){
        try{
            RemoteInput[] inputs=action.getRemoteInputs(); if(inputs==null||inputs.length==0)throw new Exception("RemoteInput ausente");
            Bundle results=new Bundle(); for(RemoteInput in:inputs)results.putCharSequence(in.getResultKey(),r.text);
            Intent intent=new Intent(); RemoteInput.addResultsToIntent(inputs,intent,results); action.actionIntent.send(this,0,intent);
            store.markReply(contact); if("away".equals(r.kind))store.markAway(contact); if(!r.pause)store.conversationState(contact,r.nextState);
            store.log(contact,body,r.text,r.kind,"Regra: "+r.rule+(r.nextState.isEmpty()?"":" · fluxo: "+r.nextState)); store.signal("Resposta única enviada para "+contact);
        }catch(Exception ex){store.log(contact,body,r.text,"error","Falha RemoteInput: "+ex.getClass().getSimpleName());store.signal("Erro no envio: "+ex.getClass().getSimpleName());}
        finally{new Handler(Looper.getMainLooper()).postDelayed(()->inFlight.remove(fingerprint),60000);}
    }
    private Notification.Action findReply(Notification.Action[] actions){if(actions==null)return null;for(Notification.Action a:actions){if(a==null||a.actionIntent==null)continue;RemoteInput[] ri=a.getRemoteInputs();if(ri!=null&&ri.length>0)return a;}return null;}
    private boolean allowed(String contact,String lines){String c=AppStore.norm(contact);for(String s:lines.split("\\r?\\n"))if(c.equals(AppStore.norm(s)))return true;return false;}
    private static String cs(CharSequence x){return x==null?"":x.toString().trim();}
    static class JSONObjectSafe{JSONObject o;JSONObjectSafe(JSONObject x){o=x;}boolean bool(String k,boolean d){return o.optBoolean(k,d);}String str(String k){return o.optString(k,"");}int integer(String k,int d){return o.optInt(k,d);}}
}
